package carrito_compra;

import java.util.ArrayList;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Compra comp = new Compra(21,134,12,175);
		ArrayList<Compra> carrito = new ArrayList<Compra>();
		
		
		//Aqui vamos a introducir un ejemplo como lo muestra todo por pantalla
		System.out.println(""+comp);
	}

}
